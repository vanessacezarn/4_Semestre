package conexao;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Classe para realizar a conexão com o Banco de Dados
 */
public class Conexao {
    public Connection getConexao(){
        try{
            Connection coon = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdaula01?useTimeZone=true&serverTimeZone=UTC", "root", "laboratorio");
            System.out.println("Conexão realizada com sucesso!!!");
            /***
             * string da conexão, onde esta o banco
            * string do usuario do bd
            * string senha do bd
             */
            return coon;
        }
        catch(Exception  e){
            System.out.println("Erro ao conectar no Banco de Dados"+e.getMessage());
            return null;
        }
    }
}