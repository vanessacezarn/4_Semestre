package ProgramaEscola;

import DAO.PessoaDAO;
import beans.Pessoa;
import conexao.Conexao;

public class ProgramaEscola {
    public static void main(String[] args) {
        //Conexao con = new Conexao();
        //con.getConexao();
        
        Pessoa p = new Pessoa();
        p.setNome("Luiza");
        p.setSexo("F");
        p.setIdioma("Espanhol");
        
        PessoaDAO pDAO = new PessoaDAO();
        pDAO.inserir(p);
        
    }
}
