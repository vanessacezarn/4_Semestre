/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco.de.dados.escola;

import Conexao.Conexao;
import DAO.AlunosDAO;
import beans.Alunos;

/**
 *
 * @author thiag
 */
public class BancoDeDadosEscola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Alunos a = new Alunos();
        a.setNome("luiza");
        a.setIdade(20);
        a.setCurso("ciência da computação");
        
        AlunosDAO aDAO = new AlunosDAO();
        aDAO.inserir(a);
        
    }
    
}
