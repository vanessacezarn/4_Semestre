/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atividade;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author thiag
 */
public class Arquivo {
    private FileWriter arqw;
	private BufferedWriter escritor;
	private FileReader arqr;
	private BufferedReader leitor;
	private ArrayList<Aluno> listAluno;
	public String nomeArquivo;
	
	public Arquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
		listAluno = new ArrayList<>();
	}
	
	public void gravaArquivo(Aluno a) {
		try {
			arqw = new FileWriter (nomeArquivo+".txt",true);
			escritor = new BufferedWriter(arqw);
			escritor.write(a.nome+";"+a.dataNascimento+";"+a.sexo+";"+a.cpf+";"+a.contato+";"+a.curso+";"+a.matricula+";"+a.rua+";"+a.numero+";"+a.cep+";"+a.bairro+";"+a.cidade+";"+a.Estado);
			escritor.newLine();
			escritor.close();
			arqw.close();
			System.out.println("Arquivos salvos com sucesso no .txt");
					
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList <Aluno> leArquivo(){
		System.out.println("alunos lidos do arquivo");
		try {
			arqr = new FileReader(nomeArquivo+".txt");
			leitor = new BufferedReader(arqr);
			String linha;
			while((linha = leitor.readLine())!=null) {
				String[]campo = linha.split(";");
				String nome = campo[0];
				String dataNascimento = campo[1];
                                String sexo = campo[2];
                                String cpf = campo[3];
                                String telefone = campo[4];
                                String curso = campo[5];
                                String matricula = campo[6];
                                String rua = campo[7];
                                String numero = campo[8];
                                String cep = campo[9];
                                String bairro = campo[10];
                                String cidade = campo[11];
                                String estado = campo[12];
                                Aluno a = new Aluno(nome,dataNascimento,sexo,cpf,telefone,curso,matricula,rua,numero,cep,bairro,cidade,estado);
				listAluno.add(a);
			}
			leitor.close();
			arqr.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		return listAluno;
	}

}
