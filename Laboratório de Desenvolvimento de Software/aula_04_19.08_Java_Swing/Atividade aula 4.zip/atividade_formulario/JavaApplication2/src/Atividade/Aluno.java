/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Atividade;

/**
 *
 * @author thiag
 */
public class Aluno {
    public String nome;
    public String dataNascimento;
    public String sexo;
    public String cpf;
    public String contato;
    public String curso;
    public String matricula;
    public String rua;
    public String numero;
    public String cep;
    public String bairro;
    public String cidade;
    public String Estado;

    public Aluno(String nome, String dataNascimento, String sexo, String cpf, String contato, String curso, String matricula, String rua, String numero, String cep, String bairro, String cidade, String Estado) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.cpf = cpf;
        this.contato = contato;
        this.curso = curso;
        this.matricula = matricula;
        this.rua = rua;
        this.numero = numero;
        this.cep = cep;
        this.bairro = bairro;
        this.cidade = cidade;
        this.Estado = Estado;
    }

    public Object[] obterDados(){
        return new Object[]{ nome,dataNascimento,sexo,cpf,contato,curso,matricula,rua,numero,cep,bairro,cidade,Estado};
        
    }
    
    
}
