/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import java.sql.*;

import Conexao.Conexao;
import beans.Alunos;
import java.util.ArrayList;
import java.util.List;
/***
 * Classe responsável por fazer consultas e/ou manipulações dos dados da tabela alunos banco de dados escola
 * @author thiag
 */
public class AlunosDAO {
    private Conexao conexao;
    private Connection conn;
    
    /***
     * Construtor da classe responsável por chamar as classes que fazem a execução com o banco de dados
     */
    public AlunosDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    /***
     * Método para inserir alunos na tabela Alunos
     * @param alunos = objeto contendo os dados a serem inseridos
     */
    public void inserir (Alunos alunos){
        String sql = "INSERT INTO alunos (nome, idade, curso) VALUES (?,?,?);";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, alunos.getNome());
            stmt.setInt(2, alunos.getIdade());
            stmt.setString(3, alunos.getCurso());
            
            stmt.execute();
        }catch(Exception ex){
            System.out.println("Erro ao inserir aluno: "+ex.getMessage());
        }        
    }
    /***
     * método para procurar um aluno
     * @param id = identificador único de cada aluno
     * @return 
     */
    public Alunos getPessoa(int id){
        String sql = "SELECT * FROM alunos WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            Alunos a = new Alunos();
            rs.first();
            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setIdade(rs.getInt("idade"));
            a.setCurso(rs.getString("curso"));
            return a;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar aluno: "+ex.getMessage());          
            return null;
        }
    }
    /***
     * método para editar as informações de um aluno 
     * @param alunos = objeto contendo os dados a serem editados
     */
    public void editar(Alunos alunos){
        try{
            String sql = "UPDATE alunos set nome=?, idade=?, curso=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, alunos.getNome());
            stmt.setInt(2, alunos.getIdade());
            stmt.setString(3, alunos.getCurso());
            stmt.setInt(4, alunos.getId());
            stmt.execute();
            
        }catch(SQLException ex){
            System.out.println("Erro ao editar alunos: "+ex.getMessage());
        }
    }
    /***
     * Método que possibilita excluir um aluno do banco de dados
     * @param id = identificação única (Chave primária) de cada aluno cadastrado no banco de dados
     */
    public void excluir(int id){
        try {
            String sql = "DELETE FROM alunos WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir alunos: "+ex.getMessage());
        } 
    }
    
    /***
     * Método que recupera todos os dados da tabela alunos
     * os dados da tabela são convertidos em objetos e salvos em uma lista
     * @return = lista de objetos com os dados de todos os alunos salvos na tabela
     */
    public List<Alunos> getAlunos(){
        String sql = "SELECT * FROM alunos";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            List<Alunos> listaAlunos = new ArrayList();
            while(rs.next()){
                Alunos a = new Alunos();
                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setIdade(rs.getInt("idade"));
                a.setCurso(rs.getString("curso"));
                listaAlunos.add(a);
            }
            return listaAlunos;              

        }catch(SQLException ex){
            System.out.println("Erro ao consultar todos os alunos do banco de dados"+ex.getMessage());
            return null;        
        }
    }
    
    public List<Alunos> getAlunoFiltro(String nome, String curso){
        String sql = "SELECT * FROM alunos WHERE nome LIKE ? and curso LIKE ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%"+ nome +"%");
            stmt.setString(2, "%"+ curso +"%");
            ResultSet rs = stmt.executeQuery();
            List <Alunos> listaAlunos = new ArrayList();
            while(rs.next()){
                Alunos a = new Alunos();
                a.setId(rs.getInt("id"));
                a.setNome(rs.getString("nome"));
                a.setIdade(rs.getInt("idade"));
                a.setCurso(rs.getString("curso"));
                listaAlunos.add(a);
            }
            return listaAlunos;
            
        }catch(SQLException e){
            System.out.println("Erro ao consultar alunos "+ nome +e.getMessage());
            return null;
            
        }
    }
  
}
