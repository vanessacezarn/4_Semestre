/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import beans.Professores;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author thiag
 */
public class ProfessoresDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ProfessoresDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir (Professores professores){
        String sql = "INSERT INTO professores (nome, idade, disciplina) VALUES (?,?,?);";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, professores.getNome());
            stmt.setInt(2, professores.getIdade());
            stmt.setString(3, professores.getDisciplina());
            
            stmt.execute();
        }catch(Exception ex){
            System.out.println("Erro ao inserir pessoa: "+ex.getMessage());
        }        
    }
    /***
     * método para procurar um aluno
     * @param id = identificador único de cada aluno
     * @return 
     */
    public Professores getPessoa(int id){
        String sql = "SELECT * FROM professores WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            Professores p = new Professores();
            rs.first();
            p.setId(id);
            p.setNome(rs.getString("nome"));
            p.setIdade(rs.getInt("idade"));
            p.setDisciplina(rs.getString("disciplina"));
            return p;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar professor: "+ex.getMessage());          
            return null;
        }
    }
    /***
     * Método para editar as informações de um professor
     * @param professores 
     */
    public void editar(Professores professores){
        try{
            String sql = "UPDATE professores set nome=?, idade=?, disciplina=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, professores.getNome());
            stmt.setInt(2, professores.getIdade());
            stmt.setString(3, professores.getDisciplina());
            stmt.setInt(4, professores.getId());
            stmt.execute();
            
        }catch(SQLException ex){
            System.out.println("Erro ao editar professor: "+ex.getMessage());
        }
    }
    /***
     * Método para excluir um professor
     * @param id 
     */
    public void excluir(int id){
        try {
            String sql = "DELETE FROM professores WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir professor: "+ex.getMessage());
        }   
    }
       /***
     * Método que recupera todos os dados da tabela alunos
     * os dados da tabela são convertidos em objetos e salvos em uma lista
     * @return = lista de objetos com os dados de todos os alunos salvos na tabela
     */
    public List<Professores> getProfessores(){
        String sql = "SELECT * FROM professores";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            List<Professores> listaProfessores = new ArrayList();
            while(rs.next()){
                Professores p = new Professores();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setIdade(rs.getInt("idade"));
                p.setDisciplina(rs.getString("disciplina"));
                listaProfessores.add(p);
            }
            return listaProfessores;              

        }catch(SQLException ex){
            System.out.println("Erro ao consultar todos os professores do banco de dados "+ex.getMessage());
            return null;        
        }
    }
    
    public List<Professores> getProfessoresFiltro(String nome, String disciplina){
        String sql = "SELECT * FROM professores WHERE nome LIKE ? and disciplina LIKE ?";
        try{
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%"+ nome +"%");
            stmt.setString(2, "%"+ disciplina +"%");
            ResultSet rs = stmt.executeQuery();
            List <Professores> listaAlunos = new ArrayList();
            while(rs.next()){
                Professores p = new Professores();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setIdade(rs.getInt("idade"));
                p.setDisciplina(rs.getString("disciplina"));
                listaAlunos.add(p);
            }
            return listaAlunos;
            
        }catch(SQLException e){
            System.out.println("Erro ao consultar alunos "+ nome +e.getMessage());
            return null;
            
        }
    }
    
}
