/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import beans.Pessoa;
import beans.Veiculo;
import conexao.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public VeiculoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir (Veiculo v){
        try {
            String sql = "INSERT INTO veiculo (modelo, placa, id_pessoa) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, v.getModelo());
            stmt.setString(2, v.getPlaca());
            stmt.setInt(3, v.getPessoaid().getId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir Veiculo: "+ex.getMessage());
        }
    }
    
    public void editar (Veiculo v){
        try {
            String sql = "UPDATE veiculo set modelo=?, placa=?, id_pessoa=? WHERE id=?";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, v.getModelo());
            stmt.setString(2, v.getPlaca());
            stmt.setInt(3, v.getPessoaid().getId());
            stmt.setInt(4, v.getId());
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar o Veiculo"+ex.getMessage());
        }   
    }
    public void excluir(int id){
        try {
            String sql = "DELETE FROM veiculo WHERE id=?";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir o Veiculo"+ex.getMessage());
        }
        
    }
 
    public List<Veiculo> getVeiculo(){
        try {
            String sql = "SELECT * FROM veiculo";
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery();
            List<Veiculo> listaVeiculo = new ArrayList();
            while(rs.next()){
                Veiculo v = new Veiculo();
                v.setId(rs.getInt("id"));
                v.setModelo(rs.getString("modelo"));
                v.setPlaca(rs.getString("placa"));
                
                int idPessoa = rs.getInt("id_pessoa");
                PessoaDAO pdao = new PessoaDAO();
                Pessoa p = pdao.getPessoa(idPessoa);
                v.setPessoaid(p);
                listaVeiculo.add(v);
            }
            return listaVeiculo;
        } catch (SQLException ex) {
            System.out.println("Erro ao consutar todos os veiculos"+ex.getMessage());
            return null;
        }
    }
}
