/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Conexao.Conexao;
import beans.Produtos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author laboratorio
 */
public class ProdutosDAO {
    private Conexao Conexao;
    private Connection conn;

    /**
     * Construtor da classe utilizado para realizar a conexão com banco 
     * utiliza a classe conexao do pacote conexao
     */
    public ProdutosDAO(){
        this.Conexao =  new Conexao();
        this.conn = this.Conexao.getConexao();
    }
    /**
     * método responsável pela inserção de novos produtos no banco de dados
     * @param p objeto da classe Produtos que contem os dados do produtos que será adicionado
     */
    public void inserir(Produtos p){
        try {
            String sql = "INSERT INTO produtos(nome, preco, saldo) VALUES (?, ?, ?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, p.getNome());
            stmt.setFloat(2, p.getPreco());
            stmt.setInt(3, p.getSaldo());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("ERRO AO INSERIR PRODUTO : "+ex.getMessage());
        }
    }
    /**
     * método responsável pela pesquisa de todos os produtos cadastrados no banco de dados
     * @return lista com todos os produtos ou null, caso não consiga consultar
     */ 
    public List<Produtos> getProdutos(){
        try {
            String sql = "SELECT * FROM produtos";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            List<Produtos>listaProdutos = new ArrayList();
            while (rs.next()){
                Produtos p = new Produtos();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPreco(rs.getFloat("preco"));
                p.setSaldo(rs.getInt("saldo"));
                listaProdutos.add(p);
            }
            return listaProdutos;

        } catch (SQLException ex) {
            System.out.println("ERRO AO CONSULTAS TODAS OS PRODUTOS : "+ex.getMessage());
            return null;
        }
    }
    /**
     * método responsável por pesquisar um determinado produto através de seu id
     * @param id identificador único de cada produto
     * @return objeto, se realizar a consulta, ou null, se não realizar a consulta
     */
    public Produtos getProdutos(int id){
        try {
            String sql = "SELECT * FROM produtos WHERE id =?";
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Produtos p = new Produtos();
            rs.first();
            
            p.setId(rs.getInt("id"));
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getFloat("preco"));
            p.setSaldo(rs.getInt("saldo"));
            
            return p;            
        } catch (SQLException ex) {
            System.out.println("ERRO AO CONSULTAS PRODUTOS : "+ex.getMessage());
            return null;        }
    }
    
}
