/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import java.sql.*;

import Conexao.Conexao;
import beans.Alunos;

public class AlunosDAO {
    private Conexao conexao;
    private Connection conn;
    
    public AlunosDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    /***
     * Método para inserir alunos na tabela Alunos
     * @param alunos 
     */
    public void inserir (Alunos alunos){
        String sql = "INSERT INTO alunos (nome, idade, curso) VALUES (?,?,?);";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, alunos.getNome());
            stmt.setInt(2, alunos.getIdade());
            stmt.setString(3, alunos.getCurso());
            
            stmt.execute();
        }catch(Exception ex){
            System.out.println("Erro ao inserir aluno: "+ex.getMessage());
        }        
    }
    /***
     * método para procurar um aluno
     * @param id = identificador único de cada aluno
     * @return 
     */
    public Alunos getPessoa(int id){
        String sql = "SELECT * FROM alunos WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            
            Alunos a = new Alunos();
            rs.first();
            a.setId(id);
            a.setNome(rs.getString("nome"));
            a.setIdade(rs.getInt("idade"));
            a.setCurso(rs.getString("curso"));
            return a;
            
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar aluno: "+ex.getMessage());          
            return null;
        }
    }
    /***
     * método para editar as informações de um aluno 
     * @param alunos 
     */
    public void editar(Alunos alunos){
        try{
            String sql = "UPDATE alunos set nome=?, idade=?, curso=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, alunos.getNome());
            stmt.setInt(2, alunos.getIdade());
            stmt.setString(3, alunos.getCurso());
            stmt.setInt(4, alunos.getId());
            stmt.execute();
            
        }catch(SQLException ex){
            System.out.println("Erro ao editar alunos: "+ex.getMessage());
        }
    }
    
    public void excluir(int id){
        try {
            String sql = "DELETE FROM alunos WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir alunos: "+ex.getMessage());
        }
        
        
    }
    
  
}
